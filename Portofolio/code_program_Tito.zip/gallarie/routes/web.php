<?php
use App\Http\Controllers\gallariecontroller;
use Illuminate\Support\Facades\Route;
use App\Models\album;
use App\Models\foto;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
//tampilan awal
Route::get('/', function () {
   // $fotos = Foto::all();
    return view('welcome'); 
    //, compact('fotos'));
});

//register
Route::get('/daftar', function () {
    return view('daftar');
});
Route::post('/daftar',[gallariecontroller::class, 'daftar']);

//login
Route::get('/masuk', function () {
    return view('masuk');   
});
Route::post('/LoginAksi',[gallariecontroller::class, 'LoginAksi']);

//homepage
Route::get('/homepage', function () {
    $fotos = Foto::all();
    return view('homepage', compact('fotos')); 
});

//album
Route::get('/buatalbum', function () {
    return view('buatalbum'); 
});
Route::post('/buatalbum',[gallariecontroller::class, 'buatalbum']);

Route::get('/album',[gallariecontroller::class, 'album']);
Route::get('/lihatalbum/{AlbumID}',[gallariecontroller::class, 'lihatalbum']);
Route::get('/lihatalbum', function () {
   return view('lihatalbum'); 
});


//foto
Route::get('/foto', function () {
    return view('foto'); 
});

Route::get('/unggahfoto', function () {
    $album = Album::all();
    return view('unggahfoto', compact('album')); 
});
Route::get('/foto',[gallariecontroller::class, 'foto']);
Route::post('/unggahfoto',[gallariecontroller::class, 'unggahfoto']);

Route::get('/lihatfoto/{FotoID}', [gallariecontroller::class, 'lihatFoto']);

//like komen
Route::get('/likefoto/{FotoID}', [gallariecontroller::class, 'like']);
Route::get('/tambahkomentar/{FotoID}', [gallariecontroller::class, 'komentarFoto']);


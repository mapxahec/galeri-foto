<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>foto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .image-overlay {
            max-width: 600px;
            margin: 20px auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            box-sizing: border-box;
        }

        img {
            max-width: 100%;
            border-radius: 8px;
        }

        .like {
            margin-top: 20px;
        }

        .like a {
            text-decoration: none;
            color: #333;
            display: inline-block;
            margin-right: 10px;
            cursor: pointer;
        }

        .like i {
            font-size: 20px;
            vertical-align: middle;
        }

        .like .count {
            font-size: 16px;
            margin-left: 5px;
        }

        .desk {
            margin-top: 20px;
        }

        .desk h3 {
            margin: 0 0 10px;
            font-size: 24px;
        }

        .desk p {
            margin: 0 0 5px;
            font-size: 16px;
        }

        .komentarFoto {
            margin-top: 20px;
        }

        .kom-left {
            border-bottom: 1px solid #ccc;
            padding-bottom: 10px;
            margin-bottom: 10px;
        }

        .kom-left:last-child {
            border-bottom: none;
            padding-bottom: 0;
            margin-bottom: 0;
        }

        .user-com {
            font-weight: bold;
            margin-bottom: 5px;
        }

        .isi-com {
            margin-bottom: 5px;
        }

        .tgl-com {
            color: #999;
            font-size: 12px;
        }

        .create-com input[type="text"] {
            width: calc(100% - 50px);
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-right: 10px;
            box-sizing: border-box;
        }

        .create-com button {
            padding: 8px 15px;
            border: none;
            background-color: #007bff;
            color: #fff;
            border-radius: 4px;
            cursor: pointer;
        }

        .create-com button:hover {
            background-color: #0056b3;
        }


      .button-kembali button {
            background-color:  #948362; 
            color: black; 
        }

        .button-kembali button:hover {
            background-color: white; 
            color: black; 
        }

    </style>

</head>
<body>
    <div class="button-kembali">
        <a href="/homepage">
            <button type="button"> < Kembali</button>
        </a>
    </div>
    <div class="image-overlay">
        <img src="<?php echo e(Storage::url($foto->LokasiFile)); ?>" alt="">
        <div class="like">
            <?php if(session('user') && $cek = $like->where('UserID', session('user')->UserID)->where('FotoID', $foto->FotoID)->first()): ?>

                <a href="/likefoto/<?php echo e($foto->FotoID); ?>">
                    <i class="fa-solid fa-thumbs-up"></i>
                </a>
                <span class="count"><?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?></span>
            <?php else: ?>
                <a href="/likefoto/<?php echo e($foto->FotoID); ?>">
                    <i class="fa-regular fa-thumbs-up"></i>
                </a>
                <span class="count"><?php echo e($like->where('FotoID', $foto->FotoID)->count()); ?></span>
            <?php endif; ?>

            <div class="desk">
                <h3>JudulFoto:<?php echo e($foto->JudulFoto); ?></h3>
                <p>Deskripsi foto:<?php echo e($foto->DeskripsiFoto); ?></p>
                <p>Di upload: <?php echo e($user->NamaLengkap); ?></p>
            </div>

            <div class="komentarFoto">
                <?php $__currentLoopData = $komentar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $komen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                    <div class="kom-left">
                        <div class="user-com"><?php echo e($komen->UserID); ?></div>
                        <div class="isi-com"><?php echo e($komen->IsiKomentar); ?></div>
                        <div class="tgl-com"><?php echo e($komen->TanggalKomentar); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="create-com">
                <form action="/tambahkomentar/<?php echo e($foto->FotoID); ?>" method="get">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="isi" placeholder="Masukan komentarmu..." required>
                    <button type="submit"><i class="fa-solid fa-paper-plane"></i> Kirim</button>
                </form>
            </div>
        </div>
    </div>


<script src="https://kit.fontawesome.com/29c53c391a.js" crossorigin="anonymous"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\gallarie\resources\views/lihatfoto.blade.php ENDPATH**/ ?>
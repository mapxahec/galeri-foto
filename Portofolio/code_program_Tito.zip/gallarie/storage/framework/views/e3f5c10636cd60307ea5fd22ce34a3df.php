<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Masuk</title>

<style>
body{
background-color: #948362; 
}

.login-container {
 width: 300px;
 padding: 16px;
 background-color: white;
 margin: 0 auto;
 margin-top: 100px;
 border: 1px solid black;
 border-radius: 4px;
}

.input-field {
 margin-bottom: 20px;
}

.input-field label {
 display: block;
 margin-bottom: 4px;
}

.input-field input {
 width: 95%;
 padding: 8px;
 border: 1px solid grey;
 border-radius: 4px;
}

.login-button {
 text-align: center;
}

.login-button button {
 width: 140px;
 padding: 8px;
 background-color: red;
 color: white;
 border: none;
 border-radius: 4px;
 cursor: pointer;
}

.login-button button:hover {
 background-color: #948362;
}

</style>

</head>
<body>
    <div class="login-container">
        <center><h1>Masuk</h1></center>
       <center><p><?php echo session('gal'); ?></p></center>
    <form action="LoginAksi" method ="POST">
        <?php echo csrf_field(); ?>
    <div class="input-field">
        <label for="Username"><b>Username</b></label>
        <input type="text" id="Username" name="Username" required>
    </div>
    <div class="input-field">
        <label for="Password"><b>Password</b></label>
        <input type="Password" id="Password" name="Password" required>
    </div>
    <div class="login-button">
        <button type="submit"><b>Login</b></button>
     </div>
    </div>
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\gallarie\resources\views/masuk.blade.php ENDPATH**/ ?>
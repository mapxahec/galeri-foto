<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Foto</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/album/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  
    <style>
         .card {
            transition: transform 0.3s ease;
            cursor: pointer;
        }

        .card:hover {
            transform: translateY(-5px); /* Adjust this value as per your preference */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Add shadow on hover */
        }  

        .button-kembali {
            position: absolute;
            top: 20px;
            left: 20px;
        }

        .button-kembali button {
            background-color: #948362; 
            color: black; 
        }

        .button-kembali button:hover {
            background-color: white; 
            color:black; 
        }


    </style>
</head>
<body>
  <div class="button-kembali">
    <a href="/homepage">
        <button type="button"> < Kembali</button>
    </a>
</div>
 
  <section class="py-5 text-center container">
    <div class="row py-lg-5">
      <div class="col-lg-6 col-md-8 mx-auto">
        <h1 class="fw-light">Foto</h1>
        <p class="lead text-body-secondary">Unggah foto anda sekarang</p>
        <p>
          <a href="unggahfoto" class="btn btn-primary my-2">+ Unggah Foto</a>
        </p>
      </div>
    </div>
  </section>

<h1>Foto</h1>
<div class="row" style="display: grid;grid-template-columns: auto auto auto; padding: 10px 100px;">
  @foreach ($fotos as $foto)
      <div class="col-md-4" style="width: 300px;">
        <a href="lihatfoto/{{$foto->FotoID}}" class="card-link">
          <div class="card">
              <img src="{{Storage::url($foto->LokasiFile)}}" class="card-img-top" alt="{{ $foto->LokasiFile}}">
              <div class="card-body">
                  <h5 class="card-title">{{ $foto->JudulFoto }}</h5>
                  <p class="card-text">{{ $foto->DeskripsiFoto }}</p>
              </div>
          </div>
        </a>
      </div>
  @endforeach
</div>
</body>
</html>
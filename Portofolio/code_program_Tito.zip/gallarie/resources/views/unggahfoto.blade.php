<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Unggah Foto</title>

    <style>
    body {
        font-family: Arial, sans-serif;
        background-color: #948362;
        margin: 0;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        height: 100vh;
    }

    form {
        background-color: #fff;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        width: 400px;

    }

    label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
    }

    input, textarea, button {
        width: 100%;
        padding: 8px;
        margin-bottom: 16px;
        box-sizing: border-box;
        border: 1px solid #ccc;
        border-radius: 4px;
    }

    button {
        background-color: red;
        color: #fff;
        padding: 10px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }

    button:hover {
        background-color: #948362;
    }
    .button-kembali {
        position: absolute;
        top: 20px;
        left: 20px;
    }

    .button-kembali button {
        background-color: white; 
        color: black; 
    }

    .button-kembali button:hover {
        background-color: #948362; 
        color: white; 
    }

    </style>

</head>
<body>
    <div class="button-kembali">
        <a href="/foto">
            <button type="button"> < Kembali</button>
        </a>
    </div>

    <form action="unggahfoto" method="POST" enctype="multipart/form-data">
        @csrf
    <div class="container">
        <center><b>Unggah Foto</b></center>
        <label for="JudulFoto">JudulFoto:</label>
        <input type="text" name="JudulFoto" required>
    
        <label for="DeskripsiFoto">Deskripsi Foto:</label>
        <textarea name="DeskripsiFoto" required></textarea>
    
        <label for="LokasiFile">Masukan Foto:</label>
        <input type="file" name="gambar", accept=".png, .jpg, .jpeg, .svg" required>
        
       <select class="form-select" name="album">
        <option selected>Pilih Album</option>
        @foreach($album as $alb)
        <option value="{{$alb->AlbumID}}">{{$alb->NamaAlbum}}</option>
        @endforeach
       </select>
        <center><button type="submit">Unggah Foto</button></center>
    </form>
</body>
</html>
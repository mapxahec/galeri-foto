<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Daftar</title>

    <style>

        body{
            background-color: #948362
        }

        .container {
            width: 300px;
            padding: 16px;
            background-color: white;
            margin: 0 auto;
            margin-top: 100px;
            border: 1px solid black;
            border-radius: 4px;
        }

        input[type=text], input[type=password] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        input[type=text], input[type=email] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: red;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            opacity: 0.8;
            background-color: #948362;
        }
    </style>

</head>
<body>
    <form action="daftar" method="POST">
        @csrf
    <div class="container">
       <center><b><h1>Daftar</h1></b></center>
        <label for="Username"><b>Username</b></label>
        <input type="text" id="Username" name="Username" required>
    
        <label for="Password"><b>Password</b></label>
        <input type="password" id="Password" name="Password" required>
    
        <label for="Email"><b>Email</b></label>
        <input type="email" id="Email" name="Email" required>
    
        <label for="NamaLengkap"><b>Nama lengkap</b></label>
        <input type="text" id="NamaLengkap" name="NamaLengkap" required>
    
        <label for="Alamat"><b>Alamat</b></label>
        <input type="text" id="Alamat" name="Alamat" required>
    
        <button type="submit">Daftar</button>
    </div>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Album</title>
    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/album/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
  
    <style>
         .button-kembali {
            position: absolute;
            top: 20px;
            left: 20px;
        }

        .button-kembali button {
            background-color: #948362; 
            color: black; 
        }

        .button-kembali button:hover {
            background-color: white; 
            color:black; 
        }

   
      </style>
</head>
<body>
  <div class="button-kembali">
    <a href="/homepage">
        <button type="button"> < Kembali</button>
    </a>
</div>
    <section class="py-5 text-center container">
        <div class="row py-lg-5">
          <div class="col-lg-6 col-md-8 mx-auto">
            <h1 class="fw-light">Album</h1>
            <p class="lead text-body-secondary">Buat dan bedakan moment-moment terbaik anda</p>
            <p>
              <a href="buatalbum" class="btn btn-primary my-2">+ Buat Album</a>
            </p>
          </div>
        </div>
      </section>

<!-- resources/views/albums/index.blade.php -->

<!-- resources/views/albums/index.blade.php -->

<h1>Album</h1>

<div class="row">
    @foreach($albums as $album)
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">{{ $album->NamaAlbum }}</h5>
                    <p class="card-text">{{ $album->Deskripsi }}</p>
                    <p class="card-text">Tanggal Dibuat: {{ $album->TanggalDibuat }}</p>
                    <center><a href="/lihatalbum/{{$album->AlbumID}}" class="btn btn-primary">Lihat Foto</a></center>
                </div>
            </div>
        </div>
    @endforeach
</div>




    {{--}}  @foreach($album as $alb)
        {{$alb->NamaAlbum}} <br>
        {{$alb->Deskripsi}}
      @endforeach
    {{-- <div class="card" style="width: 20rem;">
    <img src="img/pertama.png" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">random</h5>
      <p class="card-text">Hal random</p>
      <a href="#" class="btn btn-primary">Lihat album</a>
    </div>
  </div>

  <div class="card" style="width: 20rem;">
    <img src="img/pertama.png" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title">random</h5>
      <p class="card-text">Hal random</p>
      <a href="lihatalbum" class="btn btn-primary">Lihat album</a>
    </div>
  </div> --}}

</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
  <html lang="en" class="h-100" data-bs-theme="auto">
  <head><script src="/docs/5.3/assets/js/color-modes.js"></script>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Gallarie</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.3/examples/cover/">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@docsearch/css@3">

    <link href="/docs/5.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <style>

        body{
            background:url('img/pertama.png')
        }
        .background{
          width:fit-content;
        }
 
    </style>

    <link href="cover.css" rel="stylesheet">
  </head>
  <body class="d-flex h-100 text-center text-bg-dark">
    
<div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">
  <header class="mb-auto">
    <div>
      <h3 class="float-md-start mb-0">Gallarie</h3>
    </div>
  </header>

  <main class="px-3">
    <h1>Selamat Datang di Gallarie </h1>
    <p class="lead">Bergabung dan upload foto anda</p>
    <p class="lead">
      <a href="daftar" class="btn btn-lg btn-light fw-bold border-white bg-white mt-4">Daftar</a>
      <a href="masuk" class="btn btn-lg btn-light fw-bold border-white bg-white ms-2 mt-4">Masuk</a>
    </p>
  </main>

 {{--}} <h1>Foto</h1>
<div class="row" style="display: grid;grid-template-columns: auto auto auto; padding: 10px 100px;">
  @foreach ($fotos as $foto)
      <div class="col-md-4" style="width: 300px;">
        <a href="lihatfoto/{{$foto->FotoID}}" class="card-link">
          <div class="card">
              <img src="{{Storage::url($foto->LokasiFile)}}" class="card-img-top" alt="{{ $foto->LokasiFile}}">
              <div class="card-body">
                  <h5 class="card-title">{{ $foto->JudulFoto }}</h5>
                  <p class="card-text">{{ $foto->DeskripsiFoto }}</p>
              </div>
          </div>
        </a>
      </div>
  @endforeach
  
</div>
--}}   
  <footer class="mt-auto text-white-50">
    
  </footer>
</body>
</html>

<?php

namespace App\Http\Controllers;
use App\Models\album;
use Illuminate\Http\Request;
use App\Models\User;
use Carbon\Carbon;
use App\Models\foto;
use App\Models\likefoto;
use App\Models\komentarfoto;


class gallariecontroller extends Controller
{
    public function welcome(Request $request){
        $fotos = Foto::all();
        return view('foto', compact('fotos'));
      }

//register
    public function daftar(Request $request){
        $data = new User();
        $data->Username = $request->input('Username');
        $data->Password = $request->input('Password');
        $data->Email = $request->input('Email');
        $data->NamaLengkap = $request->input('NamaLengkap');
        $data->Alamat = $request->input('Alamat');
        $data->save();
        return redirect('masuk')->with('ber','Registrasi berhasi');
    }

//login
    public function LoginAksi(Request $reg){
        $data = User::where('Username', $reg->input('Username'))->where('Password', $reg->input('Password'))->first();
         if ($data == null){
             return redirect('masuk')->with('gal','username/password anda salah');
         } else {
             session()->put('User', $data);
             return redirect('homepage')->with('ber','Selamat datang '. $data->Username);
         }
     }

     public function homepage(Request $request){
        $fotos = Foto::all();
        return view('foto', compact('fotos'));
      }

//album
    public function buatalbum(Request $request){
        $data = new album();
        $data->NamaAlbum = $request->input('NamaAlbum');
        $data->Deskripsi = $request->input('Deskripsi');
        $data->TanggalDibuat = Carbon::now();
        $data->UserID = session('User')->UserID;
        $data->save();
        return redirect('album')->with('ber','album berhasil dibuat');
    }

    public function album(Request $request){
      $albums = Album::all();
      return view('album', compact('albums'));
    }
      
    public function lihatalbum($AlbumID) {
        $albums = Album::find($AlbumID);
        $fotos = Foto::where('AlbumID', $AlbumID)->get();
        return view('lihatalbum', compact('fotos'));
    }

    

//foto
    public function unggahfoto(Request $request){
        if ($request->hasfile('gambar')){
        $locate = $request->file('gambar')->store('public/images');
        $data = new foto();
        $data->JudulFoto = $request->input('JudulFoto');
        $data->DeskripsiFoto = $request->input('DeskripsiFoto');
        $data->TanggalUnggah = Carbon::now();
        $data->LokasiFile = $locate;
        $data->AlbumID = $request->input('album');
        $data->UserID = session('User')->UserID;
        $data->save();
        return redirect('foto')->with('ber','album berhasil dibuat');
        }else{
        return redirect('unggahfoto')->with('gal','gagal');
}
}

     public function foto(Request $request){
         $fotos = Foto::all();
         return view('foto', compact('fotos'));
      }

    public function lihatFoto($FotoID) {
        $foto = foto::where('FotoID', $FotoID)->first();
        $like = Likefoto::all();
        $komentar = KomentarFoto::where('FotoID', $FotoID)->get();
        $user = User::find($foto->UserID);
        $user2 = User::all(); 

        return view('lihatfoto', compact('foto','like','komentar','user2','user'));

        }
    

        
public function like($FotoID){
    $cek = Likefoto::where('UserID', session('User')->UserID)->where('FotoID', $FotoID)->first();
    if(!$cek){
        $like = new Likefoto;
        $like->FotoID = $FotoID;
        $like->UserID = session('User')->UserID;
        $like->TanggalLike = Carbon::now();
        $like->save();
        
        return redirect()->back();
    }else{
        $cek->delete();

        return redirect()->back();
    }
}
public function komentarFoto($FotoID, Request $req){
    $komen = new Komentarfoto;
    $komen->FotoID = $FotoID;
    $komen->UserID = session('User')->UserID;
    $komen->IsiKomentar = $req->input('isi');
    $komen->TanggalKomentar = Carbon::now();
    $komen->save();

    return redirect()->back();
}

// public function foto()
// {
//   return view('foto', [
//     'fotos' => Foto::where('UserID', session('data')->UserID)->get()
//     ]);
// }

}
